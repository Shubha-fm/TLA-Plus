----------------------- MODULE RailwayCrossing -----------------------
EXTENDS Naturals
VARIABLES approaching, closed, crossing
vars == <<approaching, closed, crossing>>
Init == /\ approaching = FALSE /\ closed = FALSE /\ crossing = FALSE
Approach == /\ ~approaching /\ ~crossing
            /\ approaching' = TRUE /\ UNCHANGED <<closed, crossing>>
Close == /\ ~closed /\ closed' = TRUE /\ UNCHANGED <<approaching, crossing>>
Enter == /\ approaching /\ closed /\ ~crossing
         /\ approaching' = FALSE /\ crossing' = TRUE /\ UNCHANGED closed
Leave == /\ crossing /\ crossing' = FALSE /\ UNCHANGED <<approaching, closed>>
Open == /\ closed /\ ~approaching /\ ~crossing
        /\ closed' = FALSE /\ UNCHANGED <<approaching, crossing>>
Next == Approach \/ Close \/ Enter \/ Leave \/ Open
Spec == Init /\ [][Next]_vars
TypeOK == approaching \in BOOLEAN /\ closed \in BOOLEAN /\ crossing \in BOOLEAN
TrainProtected == crossing => closed
TrainNotApproachingWhileCrossing == ~(approaching /\ crossing)
=======================================================================
