---------------------------- MODULE JobQueue ----------------------------
EXTENDS Naturals, FiniteSets
CONSTANTS Jobs, MaxAttempts
ASSUME /\ Jobs # {} /\ MaxAttempts \in Nat /\ MaxAttempts >= 1
VARIABLES status, attempts
vars == <<status, attempts>>
States == {"new", "queued", "running", "done", "failed"}
Init == /\ status = [j \in Jobs |-> "new"]
        /\ attempts = [j \in Jobs |-> 0]
Submit(j) == /\ status[j] = "new"
             /\ status' = [status EXCEPT ![j] = "queued"]
             /\ UNCHANGED attempts
Start(j) == /\ status[j] = "queued" /\ attempts[j] < MaxAttempts
            /\ status' = [status EXCEPT ![j] = "running"]
            /\ attempts' = [attempts EXCEPT ![j] = @ + 1]
Retry(j) == /\ status[j] = "running" /\ attempts[j] < MaxAttempts
            /\ status' = [status EXCEPT ![j] = "queued"]
            /\ UNCHANGED attempts
Complete(j) == /\ status[j] = "running"
               /\ status' = [status EXCEPT ![j] = "done"]
               /\ UNCHANGED attempts
Abandon(j) == /\ status[j] = "running" /\ attempts[j] = MaxAttempts
              /\ status' = [status EXCEPT ![j] = "failed"]
              /\ UNCHANGED attempts
Next == \E j \in Jobs: Submit(j) \/ Start(j) \/ Retry(j) \/ Complete(j) \/ Abandon(j)
Spec == Init /\ [][Next]_vars
TypeOK == /\ status \in [Jobs -> States]
          /\ attempts \in [Jobs -> 0..MaxAttempts]
DoneWasStarted == \A j \in Jobs: status[j] = "done" => attempts[j] > 0
FailedAtLimit == \A j \in Jobs: status[j] = "failed" => attempts[j] = MaxAttempts
RunningWasStarted == \A j \in Jobs: status[j] = "running" => attempts[j] > 0
========================================================================
