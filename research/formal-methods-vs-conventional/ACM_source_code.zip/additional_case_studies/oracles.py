"""Two independent finite-transition oracles derived from TLA+ action tables.
No implementation imports. Pure tuples allow exhaustive enumeration and replay.
These are hand-transcribed oracles, not parsed TLA+ or independently peer-reviewed proofs.
"""
RAIL_ACTIONS=('approach','close','enter','leave','open')
QUEUE_ACTIONS=('submit','start','retry','complete','abandon')

def rail_init(): return (False,False,False) # approach, barrier closed, crossing

def rail_step(s,op,i=0):
    approaching,closed,crossing=s
    if op=='approach' and not approaching and not crossing: return (True,closed,crossing),True
    if op=='close' and not closed: return (approaching,True,crossing),True
    if op=='enter' and approaching and closed and not crossing: return (False,closed,True),True
    if op=='leave' and crossing: return (approaching,closed,False),True
    if op=='open' and closed and not approaching and not crossing: return (approaching,False,crossing),True
    return s,False

def queue_init(n=2):return (('new',)*n,(0,)*n) # job status, attempt counters

def queue_step(s,op,i,max_attempts=2):
    status,attempt=s
    x=status[i]; k=attempt[i]
    if op=='submit' and x=='new':
        ss=list(status);ss[i]='queued';return (tuple(ss),attempt),True
    if op=='start' and x=='queued' and k<max_attempts:
        ss=list(status);ss[i]='running'; aa=list(attempt);aa[i]+=1
        return (tuple(ss),tuple(aa)),True
    if op=='retry' and x=='running' and k<max_attempts:
        ss=list(status);ss[i]='queued';return (tuple(ss),attempt),True
    if op=='complete' and x=='running':
        ss=list(status);ss[i]='done';return (tuple(ss),attempt),True
    if op=='abandon' and x=='running' and k==max_attempts:
        ss=list(status);ss[i]='failed';return (tuple(ss),attempt),True
    return s,False

def valid(name,s):
    if name=='rail':
        approaching,closed,crossing=s
        return not(crossing and not closed) and not(approaching and crossing)
    status,attempt=s
    return (all(x in {'new','queued','running','done','failed'} for x in status)
            and all(0<=a<=2 for a in attempt)
            and all((x not in {'running','done','failed'} or a>=1) and (x!='failed' or a==2)
                    for x,a in zip(status,attempt)))
