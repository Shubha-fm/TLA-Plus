"""Reproducible independent multi-domain mutation and conformance experiment."""
from collections import deque
import csv, hashlib, json, pathlib, random, time
from additional_case_studies.oracles import (RAIL_ACTIONS, QUEUE_ACTIONS, rail_init,
    rail_step, queue_init, queue_step, valid)
from additional_case_studies.implementations import (RAIL_MUTANTS,QUEUE_MUTANTS,
    rail_apply,queue_apply)
ROOT=pathlib.Path(__file__).resolve().parent
SEEDS=(41,42,43,44,45)

def scenario(name):
    if name=='rail':
        return rail_init(), [(op,0) for op in RAIL_ACTIONS], lambda s,a:rail_step(s,*a),rail_apply,RAIL_MUTANTS
    return queue_init(), [(op,i) for op in QUEUE_ACTIONS for i in range(2)],lambda s,a:queue_step(s,*a,2),queue_apply,QUEUE_MUTANTS

def fixed_tests(name):
    if name=='rail':
        return [[('enter',0)], [('approach',0),('close',0),('enter',0),('leave',0),('open',0)],
                [('approach',0),('open',0)], [('close',0),('open',0)],
                [('close',0),('enter',0),('open',0)], [('approach',0),('close',0),('open',0)]]
    return [[('start',0)], [('complete',0)], [('submit',0),('start',0),('complete',0)],
            [('submit',0),('start',0),('retry',0),('start',0),('complete',0)],
            [('submit',1),('submit',0),('start',0)],
            [('submit',0),('start',0),('retry',0),('start',0),('abandon',0)]]

def find_first(initial,trace,oracle,candidate,mutant):
    ref=initial;actual=initial
    for step,action in enumerate(trace,1):
        ref,accept_ref=oracle(ref,action)
        actual,accept_actual=candidate(actual,action,mutant)
        if (ref,accept_ref)!=(actual,accept_actual):
            return {'step':step,'action':list(action),'reference':repr(ref),'candidate':repr(actual),
                    'reference_accepted':accept_ref,'candidate_accepted':accept_actual}
    return None

def run(name,validation_traces_per_seed=120,validation_length=18):
    init,actions,oracle,candidate,mutants=scenario(name)
    discovered={init:((),0)};queue=deque([init]);edges=0;invalid=[];divergences={}; reference_mismatches=[]
    started=time.perf_counter()
    while queue:
        s=queue.popleft();prefix,depth=discovered[s]
        if not valid(name,s):invalid.append({'state':repr(s)})
        for action in actions:
            expected,enabled=oracle(s,action)
            actual,actual_enabled=candidate(s,action)
            edges+=1
            if (expected,enabled)!=(actual,actual_enabled):
                reference_mismatches.append({'from':repr(s),'action':list(action),'expected':repr(expected),'actual':repr(actual)})
            for mutant in mutants:
                if mutant not in divergences:
                    changed,changed_enabled=candidate(s,action,mutant)
                    if (changed,changed_enabled)!=(expected,enabled):
                        divergences[mutant]={'prefix':[list(x) for x in prefix],'trigger':list(action),
                            'expected_state':repr(expected),'candidate_state':repr(changed),
                            'expected_accepted':enabled,'candidate_accepted':changed_enabled}
            if enabled and expected not in discovered:
                discovered[expected]=(prefix+(action,),depth+1);queue.append(expected)
    rows=[]
    for mutant in mutants:
        detected_by_tests=any(find_first(init,t,oracle,candidate,mutant) for t in fixed_tests(name))
        seed_rates=[]
        for seed in SEEDS:
            rng=random.Random(seed)
            failures=0
            for _ in range(validation_traces_per_seed):
                trace=[actions[rng.randrange(len(actions))] for __ in range(validation_length)]
                failures+=bool(find_first(init,trace,oracle,candidate,mutant))
            seed_rates.append(failures/validation_traces_per_seed)
            rows.append({'case':name,'mutant':mutant,'seed':seed,'conventional_detection':int(detected_by_tests),
                         'plus_conformance_detection':int(detected_by_tests or mutant in divergences),
                         'holdout_failures':failures,'holdout_traces':validation_traces_per_seed})
    report={'case':name,'scope':'independent hand-transcribed oracle, finite reachable graph; not TLC',
        'states':len(discovered),'transitions_including_disabled':edges,'max_shortest_depth':max(d for _,d in discovered.values()),
        'source_code_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/'oracles.py',ROOT/'implementations.py',ROOT/'run_cases.py']},
        'independent_oracle_mismatches':len(reference_mismatches),'mismatch_examples':reference_mismatches[:5],
        'invariant_violations':len(invalid),'invariant_examples':invalid[:5],
        'mutants':len(mutants),'conventional_detected':sum(int(any(find_first(init,t,oracle,candidate,m) for t in fixed_tests(name))) for m in mutants),
        'augmented_detected':len(divergences),'witnesses':divergences,
        'seeds':SEEDS,'traces_per_seed':validation_traces_per_seed,'actions_per_trace':validation_length,
        'elapsed_seconds':round(time.perf_counter()-started,6)}
    return report,rows

def main():
    out=ROOT/'results';out.mkdir(exist_ok=True)
    rs=[];rows=[]
    for c in ('rail','queue'):
        r,rr=run(c);rs.append(r);rows+=rr
        print(c,':',r['states'],'states',r['transitions_including_disabled'],'checked actions; Python vs oracle mismatches',r['independent_oracle_mismatches'],'conventional',r['conventional_detected'],'augmented',r['augmented_detected'])
    (out/'independent_cases_summary.json').write_text(json.dumps(rs,indent=2))
    with (out/'independent_cases_raw.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    if any(r['independent_oracle_mismatches'] or r['invariant_violations'] for r in rs):
        raise SystemExit('Study reference/oracle mismatch or invariant violation detected')
if __name__=='__main__':main()
