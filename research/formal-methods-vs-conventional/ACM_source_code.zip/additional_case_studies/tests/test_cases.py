import unittest
from additional_case_studies.run_cases import run
class ExtraCaseStudyTests(unittest.TestCase):
    def test_independent_railway(self):
        r,_=run('rail',validation_traces_per_seed=5)
        self.assertEqual(r['independent_oracle_mismatches'],0)
        self.assertEqual(r['invariant_violations'],0)
        self.assertEqual(r['augmented_detected'],r['mutants'])
    def test_independent_job_queue(self):
        r,_=run('queue',validation_traces_per_seed=5)
        self.assertEqual(r['independent_oracle_mismatches'],0)
        self.assertEqual(r['invariant_violations'],0)
        self.assertEqual(r['augmented_detected'],r['mutants'])
if __name__=='__main__':unittest.main()
