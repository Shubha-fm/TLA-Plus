"""Candidate Python implementations under mutation. No oracle imports.
The mutations deliberately change one guard/update in a case-study handler.
"""
RAIL_MUTANTS=('enter_without_gate','open_with_train','open_during_approach',
              'leave_keeps_train','enter_keeps_approach','close_leaves_gate_open','approach_forces_train')
QUEUE_MUTANTS=('complete_without_start','start_before_submit','retry_beyond_limit',
               'retry_does_not_queue','submit_other_job','complete_other_job',
               'retry_resets_attempts','abandon_early','start_wrong_counter')

def rail_apply(state,action,mutant=None):
    op,i=action;a,c,x=state
    if op=='approach':
        if a or x:return state,False
        return (True,c,True if mutant=='approach_forces_train' else x),True
    if op=='close':
        if c:return state,False
        return (a,False if mutant=='close_leaves_gate_open' else True,x),True
    if op=='enter':
        if not a or x or (not c and mutant!='enter_without_gate'):return state,False
        return (a if mutant=='enter_keeps_approach' else False,c,True),True
    if op=='leave':
        if not x:return state,False
        return (a,c,True if mutant=='leave_keeps_train' else False),True
    if op=='open':
        if not c or (a and mutant!='open_during_approach') or (x and mutant!='open_with_train'):
            return state,False
        return (a,False,x),True
    raise ValueError(op)

def queue_apply(state,action,mutant=None):
    op,i=action; ss,aa=state;count=len(ss);other=(i+1)%count;x=ss[i]; k=aa[i]
    s=list(ss);attempt=list(aa)
    if op=='submit':
        if x!='new':return state,False
        s[other if mutant=='submit_other_job' else i]='queued'
    elif op=='start':
        if (x!='queued' and mutant!='start_before_submit') or k>=2:
            return state,False
        s[i]='running';attempt[other if mutant=='start_wrong_counter' else i]+=1
    elif op=='retry':
        if x!='running' or (k>=2 and mutant!='retry_beyond_limit'):return state,False
        if mutant!='retry_does_not_queue':s[i]='queued'
        if mutant=='retry_resets_attempts':attempt[i]=0
    elif op=='complete':
        if x!='running' and mutant!='complete_without_start':return state,False
        s[other if mutant=='complete_other_job' else i]='done'
    elif op=='abandon':
        if x!='running' or (k!=2 and mutant!='abandon_early'):return state,False
        s[i]='failed'
    else:raise ValueError(op)
    return (tuple(s),tuple(attempt)),True
