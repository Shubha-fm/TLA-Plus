"""Run the official TLC jar separately for the two new models.
This script never converts a missing jar into a PASS.
"""
import argparse, hashlib, json, pathlib, re, shutil, subprocess, tempfile, time
ROOT=pathlib.Path(__file__).resolve().parent

def run(jar,timeout,output):
    out=pathlib.Path(output);out.mkdir(parents=True,exist_ok=True)
    results=[]
    for module in ('RailwayCrossing','JobQueue'):
        model=ROOT/'spec'/f'{module}.tla';cfg=ROOT/'spec'/f'{module}.cfg'
        entry={'case':module,'tla_sha256':hashlib.sha256(model.read_bytes()).hexdigest(),
            'cfg_sha256':hashlib.sha256(cfg.read_bytes()).hexdigest()}
        if not jar or not pathlib.Path(jar).is_file():
            entry.update(status='NOT_RUN', reason='Official TLC jar not available')
        else:
            with tempfile.TemporaryDirectory(prefix='acm-tlc-'+module+'-') as tmp:
                work=pathlib.Path(tmp)
                shutil.copy2(model,work/model.name);shutil.copy2(cfg,work/cfg.name)
                cmd=['java','-XX:+UseParallelGC','-jar',str(pathlib.Path(jar).resolve()),'-workers','1',
                     '-config',cfg.name,model.name]
                start=time.perf_counter()
                try:
                    cp=subprocess.run(cmd,cwd=work,capture_output=True,text=True,timeout=timeout)
                    log=cp.stdout+'\n'+cp.stderr
                    passed=(cp.returncode==0 and 'Model checking completed. No error has been found' in log)
                    entry.update(status='PASS' if passed else 'FAIL',returncode=cp.returncode)
                except subprocess.TimeoutExpired as exc:
                    log=(exc.stdout or b'').decode(errors='replace') if isinstance(exc.stdout,bytes) else (exc.stdout or '')
                    log+='\nTIMEOUT'
                    entry.update(status='TIMEOUT',returncode=None)
                entry['elapsed_seconds']=round(time.perf_counter()-start,5)
                entry['log']=f'{module}.log'
                (out/f'{module}.log').write_text(log)
                matches=re.findall(r'(\d+) states generated, (\d+) distinct states found',log)
                if matches:
                    entry.update(generated_states=int(matches[-1][0]),distinct_states=int(matches[-1][1]))
        results.append(entry)
        print(module,entry['status'])
    (out/'tlc_extra_summary.json').write_text(json.dumps(results,indent=2))
    return results
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--jar',default=None);p.add_argument('--timeout',type=int,default=180)
    p.add_argument('--out',default=str(ROOT/'results'/'tlc'))
    args=p.parse_args();run(args.jar,args.timeout,args.out)
