--------------------------- MODULE ApprovalService ---------------------------
EXTENDS Naturals, FiniteSets
CONSTANTS Objects, MaxVersion, MaxRetries
ASSUME /\ Objects # {}
       /\ MaxVersion \in Nat
       /\ MaxVersion >= 1
       /\ MaxRetries \in Nat
VARIABLES version, approval, released, retries, lastOp, lastTarget
vars == <<version, approval, released, retries, lastOp, lastTarget>>

Init == /\ version = [o \in Objects |-> 1]
        /\ approval = [o \in Objects |-> 0]
        /\ released = [o \in Objects |-> FALSE]
        /\ retries = [o \in Objects |-> 0]
        /\ lastOp = "Init"
        /\ lastTarget = "none"

Assess(o) == /\ ~released[o]
             /\ approval' = [approval EXCEPT ![o] = version[o]]
             /\ lastOp' = "Assess"
             /\ lastTarget' = o
             /\ UNCHANGED <<version, released, retries>>

Update(o) == /\ ~released[o]
             /\ version[o] < MaxVersion
             /\ version' = [version EXCEPT ![o] = @ + 1]
             /\ approval' = [approval EXCEPT ![o] = 0]
             /\ lastOp' = "Update"
             /\ lastTarget' = o
             /\ UNCHANGED <<released, retries>>

Retry(o) == /\ ~released[o]
            /\ retries[o] < MaxRetries
            /\ retries' = [retries EXCEPT ![o] = @ + 1]
            /\ approval' = [approval EXCEPT ![o] = 0]
            /\ lastOp' = "Retry"
            /\ lastTarget' = o
            /\ UNCHANGED <<version, released>>

Release(o) == /\ ~released[o]
              /\ approval[o] = version[o]
              /\ released' = [released EXCEPT ![o] = TRUE]
              /\ lastOp' = "Release"
              /\ lastTarget' = o
              /\ UNCHANGED <<version, approval, retries>>

Next == \E o \in Objects: Assess(o) \/ Update(o) \/ Retry(o) \/ Release(o)
Spec == Init /\ [][Next]_vars

TypeOK == /\ version \in [Objects -> 1..MaxVersion]
          /\ approval \in [Objects -> 0..MaxVersion]
          /\ released \in [Objects -> BOOLEAN]
          /\ retries \in [Objects -> 0..MaxRetries]
          /\ lastOp \in {"Init", "Assess", "Update", "Retry", "Release"}
          /\ lastTarget \in Objects \cup {"none"}
NoUnsafeRelease == \A o \in Objects: released[o] => approval[o] = version[o]
ApprovalIsCurrent == \A o \in Objects: approval[o] \in {0, version[o]}
RetryInvalidates == (lastOp = "Retry") => approval[lastTarget] = 0
UpdateInvalidates == (lastOp = "Update") => approval[lastTarget] = 0
=============================================================================
