"""Evidence-grounded figures for release-controller reproducibility study.
Reads a local run CSV; never fabricates unmeasured TLC outcomes.
Usage: python -m analysis.make_figures --results LOCAL_PYTHON_RUN
Requires: matplotlib (pip install matplotlib)
"""
from __future__ import annotations
import argparse,csv,collections,statistics,math,pathlib,json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib import rcParams
rcParams.update({'font.size':9,'axes.labelsize':9,'axes.titlesize':10,'pdf.fonttype':42,'ps.fonttype':42,'savefig.bbox':'tight'})
BLUE='#214e72'; TEAL='#267d7d'; WARM='#b26b31'; GREY='#6b7280'; LIGHT='#d8e1e8'; RED='#a73734'
ROOT=pathlib.Path(__file__).resolve().parents[1]

def save(fig, stem, dest):
    fig.savefig(dest/f'{stem}.pdf',dpi=200,bbox_inches='tight',facecolor='white')
    fig.savefig(dest/f'{stem}.png',dpi=180,bbox_inches='tight',facecolor='white')
    plt.close(fig)

def boxed(ax, x,y,w,h,s,c=BLUE,fs=10):
    b=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.015,rounding_size=0.02',edgecolor=c,facecolor='white',linewidth=1.5)
    ax.add_patch(b);ax.text(x+w/2,y+h/2,s,ha='center',va='center',fontsize=fs,color=c,linespacing=1.35)

def arrow(ax,xy1,xy2,c=GREY):
    ax.add_patch(FancyArrowPatch(xy1,xy2,arrowstyle='-|>',mutation_scale=14,color=c,linewidth=1.35))

def schema(dest):
    fig,ax=plt.subplots(figsize=(11,5.1));ax.set(xlim=(0,12),ylim=(0,5));ax.axis('off')
    boxed(ax,.5,3.8,2.4,.72,'Frozen requirements\nR1--R6');boxed(ax,4,3.8,3,.72,'Formal transition model\nTLA+ / TLC');boxed(ax,8,3.8,3.3,.72,'Python reference\n+ 16 mutants')
    boxed(ax,.5,2.0,2.4,.8,'Conventional test\nscripts');boxed(ax,4,2.0,3,.8,'Bounded transition\nconformance explorer');boxed(ax,8,2.0,3.3,.8,'Held-out validation\nseeded action traces')
    boxed(ax,2.6,.25,6.6,.8,'Archived evidence: raw CSV, TLC logs (if run),\nsource hashes, state counts and witnesses',c=TEAL)
    for xy1,xy2 in [((1.7,3.8),(1.7,2.8)),((5.5,3.8),(5.5,2.8)),((9.6,3.8),(9.6,2.8)),((2.9,4.16),(4,4.16)),((7,4.16),(8,4.16)),((1.7,2),(3.6,1.05)),((5.5,2),(5.5,1.05)),((9.6,2),(7.5,1.05))]:arrow(ax,xy1,xy2)
    ax.text(5.9,4.78,'Evidence provenance and boundaries',ha='center',weight='bold',fontsize=12)
    save(fig,'evidence_pipeline',dest)

def state_machine(dest):
    fig,ax=plt.subplots(figsize=(11,4.4));ax.set(xlim=(0,12),ylim=(0,4.8));ax.axis('off')
    boxed(ax,.8,1.85,2.7,1.1,'Active / unapproved\n(version = v, approval = 0)')
    boxed(ax,4.6,1.85,2.7,1.1,'Active / approved\n(approval = version)')
    boxed(ax,8.6,1.85,2.7,1.1,'Released / terminal\n(approval = version)',c=TEAL)
    arrow(ax,(3.5,2.66),(4.6,2.66));ax.text(4.05,2.88,'assess',ha='center')
    arrow(ax,(7.3,2.46),(8.6,2.46));ax.text(8,2.72,'release',ha='center')
    arrow(ax,(4.6,2.13),(3.5,2.13));ax.text(4.05,1.86,'update / retry',ha='center',fontsize=8)
    ax.text(1.9,.75,'Update: v := v + 1 (when within bound)\nRetry: t := t + 1 (when within bound)\nBoth invalidate approval.',ha='center',fontsize=9)
    ax.text(9.9,.76,'Post-release assess, update, retry\nand second release are rejected.',ha='center',fontsize=9)
    ax.text(5.8,4.05,'Abstract controller states (not a complete TLC state graph)',ha='center',weight='bold',fontsize=12)
    save(fig,'controller_state_model',dest)

def separation(dest):
    fig,ax=plt.subplots(figsize=(11,5));ax.set(xlim=(0,12),ylim=(0,5));ax.axis('off')
    for i,(a,b,c) in enumerate([
       ('Specification','What behavior is required?','R1--R5, action contract, TLA+ model'),
       ('Verification','Is the artifact faithful to its stated contract?','Tests, conformance explorer, model checker'),
       ('Validation','Does observed behavior meet intended needs?','Held-out scenarios and stakeholder review')]):
        y=3.76-i*1.31
        boxed(ax,.5,y,2.65,.83,a,c=BLUE)
        boxed(ax,3.58,y,3.8,.83,b,c=TEAL,fs=9)
        boxed(ax,7.82,y,3.6,.83,c,c=WARM,fs=9)
        arrow(ax,(3.16,y+.41),(3.54,y+.41));arrow(ax,(7.4,y+.41),(7.78,y+.41))
    ax.text(5.9,4.82,'Questions and evidence must not be conflated',ha='center',fontsize=12,weight='bold')
    save(fig,'assurance_layers',dest)

def results_plot(rows,dest):
    cases=['small','medium','large']
    rep={c:{r['mutant']:r for r in rows if r['case']==c and r['seed']=='41'} for c in cases}
    n=[sum(int(r['mutant_applicable']) for r in rep[c].values()) for c in cases]
    convention=[sum(int(r['conventional_detected']) for r in rep[c].values() if int(r['mutant_applicable'])) for c in cases]
    augmented=[sum(int(r['formal_augmented_detected']) for r in rep[c].values() if int(r['mutant_applicable'])) for c in cases]
    fig,ax=plt.subplots(figsize=(8.4,4.6))
    xs=range(3)
    ax.bar([x-.18 for x in xs], convention,width=.36,color=GREY,label='Frozen conventional tests')
    ax.bar([x+.18 for x in xs], augmented,width=.36,color=BLUE,label='Tests + Python conformance')
    for i in range(3):
        ax.text(i-.18,convention[i]+.15,f'{convention[i]}/{n[i]}',ha='center',fontsize=9)
        ax.text(i+.18,augmented[i]+.15,f'{augmented[i]}/{n[i]}',ha='center',fontsize=9)
    ax.set_xticks(list(xs),['Small: 1 object','Medium: 2 objects','Large: 3 objects'])
    ax.set_ylabel('Applicable mutants distinguished')
    ax.set_ylim(0,max(n)+3);ax.grid(axis='y',alpha=.18);ax.legend(frameon=False,ncol=2,loc='upper left')
    ax.set_title('Python detection checks (detection is seed-invariant)')
    save(fig,'measured_mutation_detection',dest)
    f=collections.defaultdict(list)
    for row in rows:
        if int(row['mutant_applicable']):f[row['case']].append(float(row['validation_detection_rate']))
    fig,ax=plt.subplots(figsize=(8.4,4.5))
    vals=[f[c] for c in cases]
    parts=ax.boxplot(vals,tick_labels=['Small','Medium','Large'],patch_artist=True,showfliers=False,whis=(5,95))
    for p in parts['boxes']: p.set_facecolor(LIGHT);p.set_edgecolor(BLUE)
    for m in parts['medians']:m.set_color(TEAL);m.set_linewidth(2)
    ax.set_ylim(0,1.05);ax.set_ylabel('Failure proportion per mutant and seed')
    ax.set_title('Held-out action traces: descriptive distribution across mutants')
    ax.text(.01,-.21,'Mutant/seed combinations are not independent projects; whiskers show 5th--95th percentiles.',transform=ax.transAxes,fontsize=8,color=GREY)
    ax.grid(axis='y',alpha=.2)
    save(fig,'measured_holdout_failure',dest)
    st=[int(next(iter(rep[c].values()))['exploration_states_shared']) for c in cases]
    tran=[int(next(iter(rep[c].values()))['exploration_transitions_shared']) for c in cases]
    fig,ax=plt.subplots(figsize=(8.4,4.8))
    ax.plot(cases,st,marker='o',lw=2.1,color=BLUE,label='Reference states (Python explorer)')
    ax.plot(cases,tran,marker='s',lw=2.1,color=TEAL,label='Checked reference transitions')
    ax.set_yscale('log');ax.set_ylabel('Count, logarithmic scale');ax.set_xlabel('Bounded configuration')
    for i,y in enumerate(st):ax.annotate(f'{y:,}',(i,y),xytext=(-8,8),textcoords='offset points',color=BLUE)
    ax.grid(axis='y',which='both',alpha=.22);ax.legend(frameon=False,loc='upper left');ax.set_title('Python reference explorer only: no TLC state counts')
    save(fig,'measured_state_growth',dest)
    mutant_order=list(rep['large'])
    grid=[]
    for m in mutant_order:
        cells=[]
        for c in cases:
            x=rep[c][m]
            if not int(x['mutant_applicable']):cells.append(0)
            elif int(x['conventional_detected']):cells.append(1)
            elif int(x['transition_conformance_detected']):cells.append(2)
            else:cells.append(3)
        grid.append(cells)
    import matplotlib.colors as colors
    cmap=colors.ListedColormap(['#eeeeee','#607e92','#ebb257','#aa3e3e'])
    fig,ax=plt.subplots(figsize=(7.7,7.4))
    ax.imshow(grid,cmap=cmap,norm=colors.BoundaryNorm([-.5,.5,1.5,2.5,3.5],4),aspect='auto')
    ax.set_xticks(range(3),['Small','Medium','Large']);ax.set_yticks(range(len(mutant_order)),[s.replace('_',' ') for s in mutant_order],fontsize=8)
    ax.tick_params(axis='both',length=0);ax.set_title('Measured detection mechanism by mutant and configuration',fontsize=11)
    for i in range(len(mutant_order)):
        for j in range(3):ax.text(j,i,['N/A','T','+C','miss'][grid[i][j]],ha='center',va='center',color='white' if grid[i][j] in (1,3) else '#20262c',fontsize=8,weight='bold')
    ax.text(0,-.12,'T = conventional tests; +C = extra detection by Python conformance; N/A = inapplicable',transform=ax.transAxes,fontsize=8)
    save(fig,'measured_mutation_matrix',dest)
    pairs=[]
    for c in cases:
        for mutant,r in rep[c].items():
            if int(r['mutant_applicable']) and r['formal_witness_steps']:
                pairs.append((c,int(r['formal_witness_steps'])))
    fig,ax=plt.subplots(figsize=(8.2,4.1))
    buckets=[1,2,3,4,5,6,7,8]
    counts=[[sum(d==k for cc,d in pairs if cc==c) for k in buckets] for c in cases]
    bottoms=[0]*len(buckets)
    for j,c in enumerate(cases):
        ax.bar(buckets,counts[j],bottom=bottoms,width=.7,color=[GREY,BLUE,TEAL][j],label=c.capitalize())
        bottoms=[a+b for a,b in zip(bottoms,counts[j])]
    ax.set_xlim(.5,8.5);ax.set_xticks(buckets);ax.set_ylabel('Distinguished applicable mutant-case pairs')
    ax.set_xlabel('Shortest detected action-prefix length (Python explorer)');ax.legend(frameon=False,ncol=3)
    ax.grid(axis='y',alpha=.2);ax.set_title('Measured shortest conformance witnesses')
    save(fig,'measured_witness_lengths',dest)
    data={'run_kind':'Python detection and conformance outputs','seeds':sorted(set(int(x['seed']) for x in rows)),'count_per_case':dict(zip(cases,n)),
          'conventional':dict(zip(cases,convention)),'augmented':dict(zip(cases,augmented)),
          'exploration_states':dict(zip(cases,st)),'exploration_transitions':dict(zip(cases,tran)),
          'tlc':'NOT RUN'}
    (dest/'plot_source_summary.json').write_text(json.dumps(data,indent=2)+'\n')

def main():
    a=argparse.ArgumentParser();a.add_argument('--results',type=pathlib.Path,required=True);a.add_argument('--out',type=pathlib.Path,default=ROOT/'figures')
    args=a.parse_args();args.out.mkdir(exist_ok=True,parents=True)
    with (args.results/'raw_results.csv').open(newline='',encoding='utf-8') as f:rows=list(csv.DictReader(f))
    assert rows,'Results CSV is empty'
    schema(args.out);state_machine(args.out);separation(args.out);results_plot(rows,args.out)
    meta_path=args.results/'tlc_summary.json'
    summary_path=args.out/'plot_source_summary.json'
    summary=json.loads(summary_path.read_text())
    summary['tlc']=json.loads(meta_path.read_text()) if meta_path.exists() else 'NOT RUN'
    summary_path.write_text(json.dumps(summary,indent=2)+'\n')
    print('Created evidence-grounded figures in',args.out)
if __name__=='__main__':main()
