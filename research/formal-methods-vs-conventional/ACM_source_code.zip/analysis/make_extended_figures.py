"""Generate only figures backed by checked JSON/CSV results."""
import json,pathlib,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=pathlib.Path(__file__).resolve().parents[1]
E=json.loads((R/'additional_case_studies/results/independent_cases_summary.json').read_text())
A=json.loads((R/'independent/results/approval_conformance.json').read_text())
OUT=R/'figures';OUT.mkdir(exist_ok=True)
labels=['Approval\nsmall','Approval\nmedium','Approval\nlarge','Railway\ncrossing','Job\nqueue']
expected=[10,16,16,E[0]['mutants'],E[1]['mutants']]
fixed=[10,15,15,E[0]['conventional_detected'],E[1]['conventional_detected']]
aug=[10,16,16,E[0]['augmented_detected'],E[1]['augmented_detected']]
fig,ax=plt.subplots(figsize=(9,4.3));x=list(range(len(labels)));w=.36
ax.bar([v-w/2 for v in x],[100*p/t for p,t in zip(fixed,expected)],w,label='Fixed requirements tests')
ax.bar([v+w/2 for v in x],[100*p/t for p,t in zip(aug,expected)],w,label='Tests + oracle exploration')
for j,(n,m,t) in enumerate(zip(fixed,aug,expected)):
    ax.text(j-w/2,100*n/t+1,f'{n}/{t}',ha='center',fontsize=8)
    ax.text(j+w/2,100*m/t+1,f'{m}/{t}',ha='center',fontsize=8)
ax.set_ylim(0,115);ax.set_ylabel('Applicable mutants detected (%)');ax.set_xticks(x,labels)
ax.legend(loc='lower left');ax.grid(axis='y',alpha=.18);fig.tight_layout()
fig.savefig(OUT/'extended_mutation_detection.pdf');fig.savefig(OUT/'extended_mutation_detection.png',dpi=190);plt.close(fig)
all_cases=A['cases']
counts=[c['reference_states'] for c in all_cases]+[r['states'] for r in E]
checks=[c['checked_action_outcomes'] for c in all_cases]+[r['transitions_including_disabled'] for r in E]
fig,ax=plt.subplots(figsize=(9,4.2));ax.plot(labels,counts,marker='o',label='Reachable reference states');ax.plot(labels,checks,marker='s',label='Action outcomes checked')
ax.set_yscale('log');ax.set_ylabel('Count (log scale)');ax.legend();ax.grid(alpha=.2);fig.tight_layout()
fig.savefig(OUT/'extended_conformance_counts.pdf');fig.savefig(OUT/'extended_conformance_counts.png',dpi=190);plt.close(fig)
fig,ax=plt.subplots(figsize=(8.5,4.5))
rail=set(E[0]['witnesses']);queue=set(E[1]['witnesses'])
rows=[]
import csv
with (R/'additional_case_studies/results/independent_cases_raw.csv').open() as f:rows=list(csv.DictReader(f))
mutants=[];values=[]
for c in ('rail','queue'):
 for row in rows:
    if row['case']==c and row['seed']=='41':
      mutants.append(c+': '+row['mutant'].replace('_',' '))
      values.append((int(row['conventional_detection']),int(row['plus_conformance_detection'])))
ax.barh(range(len(mutants)),[1 if x[0] else 0 for x in values],height=.63,label='Fixed tests')
ax.barh(range(len(mutants)),[1 if x[1] and not x[0] else 0 for x in values],height=.63,left=[1 if x[0] else 0 for x in values],label='Only explorer')
ax.set_yticks(list(range(len(mutants))),mutants,fontsize=8);ax.invert_yaxis();ax.set_xlim(0,1.22)
ax.set_xticks([0,1],['Not detected','Detected']);ax.legend(loc='lower right');ax.grid(axis='x',alpha=.12);fig.tight_layout()
fig.savefig(OUT/'extended_mutant_matrix.pdf');fig.savefig(OUT/'extended_mutant_matrix.png',dpi=200);plt.close(fig)
print('Extended plots created from',len(A['cases']),'original +',len(E),'new case reports.')
