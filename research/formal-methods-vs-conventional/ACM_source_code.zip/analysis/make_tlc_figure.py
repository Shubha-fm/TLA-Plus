"""Rebuild TLC state-space comparison from official rerun logs and summary.

Usage: python -m analysis.make_tlc_figure --results RESULTS --output figures/measured_tlc_state_growth.pdf
Requires matplotlib. Does not invent state counts.
"""
import argparse
import json
import re
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--results', type=Path, default=Path('RESULTS'))
    parser.add_argument('--output', type=Path, default=Path('figures/measured_tlc_state_growth.pdf'))
    args = parser.parse_args()
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    data = json.loads((args.results/'tlc_summary.json').read_text())
    ordered = ['small','medium','large']
    values = {row['case']: row for row in data}
    for case in ordered:
        row = values[case]
        log = (args.results/row['log']).read_text(encoding='utf-8')
        if row['result'] != 'PASS' or row['returncode'] != 0 or 'No error has been found' not in log or '0 states left on queue' not in log:
            raise ValueError(f'Missing successful TLC evidence for {case}')
        match = re.search(r'(\d+) states generated, (\d+) distinct states found', log)
        if not match or tuple(map(int,match.groups())) != (row['states_generated'],row['distinct_states']):
            raise ValueError(f'Counts do not match log for {case}')
    generated=[values[c]['states_generated'] for c in ordered]
    distinct=[values[c]['distinct_states'] for c in ordered]
    labels=['Small\n(1 object)','Medium\n(2 objects)','Large\n(3 objects)']
    fig, ax=plt.subplots(figsize=(7.25,4.25), layout='constrained')
    xs=range(3)
    ax.plot(xs,generated,marker='o',linewidth=2.0,label='States generated')
    ax.plot(xs,distinct,marker='s',linewidth=2.0,label='Distinct states')
    ax.set_xticks(list(xs),labels)
    ax.set_yscale('log')
    ax.set_ylim(8,9e5)
    ax.set_ylabel('TLC states (log scale)')
    ax.set_title('Completed TLC state-space exploration')
    ax.grid(axis='y',alpha=.27)
    ax.legend(loc='upper left',frameon=False)
    for x, y in enumerate(generated):
        ax.annotate(f'{y:,}',(x,y),xytext=(0,8),textcoords='offset points',ha='center',fontsize=9)
    for x, y in enumerate(distinct):
        ax.annotate(f'{y:,}',(x,y),xytext=(0,-14),textcoords='offset points',ha='center',fontsize=9)
    args.output.parent.mkdir(exist_ok=True,parents=True)
    fig.savefig(args.output,bbox_inches='tight')
    if args.output.suffix.lower()=='.pdf':
        fig.savefig(args.output.with_suffix('.png'),dpi=200,bbox_inches='tight')
    plt.close(fig)
    print(f'Saved {args.output}')

if __name__=='__main__':
    main()
