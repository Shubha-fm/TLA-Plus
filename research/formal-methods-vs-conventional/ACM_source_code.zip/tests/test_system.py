import unittest
from experiment.system import initial, apply, CASES, MUTANTS
from experiment.testsuites import conventional_traces, compare_trace
from experiment.explore import explore

class TestSystem(unittest.TestCase):
    def test_baseline_is_self_consistent(self):
        for case in CASES:
            for trace in conventional_traces(case):
                self.assertIsNone(compare_trace(case, None, trace))
    def test_release_gate(self):
        c = CASES[1]
        s, accepted = apply(initial(c), ('release', 0), c)
        self.assertFalse(accepted)
        s, accepted = apply(s, ('assess', 0), c)
        self.assertTrue(accepted)
        s, accepted = apply(s, ('release', 0), c)
        self.assertTrue(accepted)
    def test_explorer_detects_mutants(self):
        case = CASES[1]
        outcome = explore(case, 60000)
        self.assertFalse(outcome['truncated_by_state_limit'])
        self.assertIn('gate_bypass', outcome['witnesses'])
        self.assertIn('cross_update', outcome['witnesses'])
        self.assertIn('retry_stale', outcome['witnesses'])
    def test_no_external_dependencies(self):
        self.assertEqual(len(MUTANTS), 16)

if __name__ == '__main__':
    unittest.main()
