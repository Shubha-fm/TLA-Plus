"""Tests isolation and config discovery with a fake process; not a TLC verification."""
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest import TestCase
from unittest.mock import patch
from subprocess import CompletedProcess
from experiment.run_experiment import run_tlc

class TestTLCLauncher(TestCase):
    def test_config_staged_and_runs_isolated(self):
        working_directories=[]
        def fake_java(cmd, **kwargs):
            wd=Path(kwargs['cwd'])
            assert (wd/'ApprovalService.tla').is_file()
            assert (wd/'ApprovalService.cfg').is_file()
            assert '-jar' in cmd
            assert 'ApprovalService.tla' == cmd[-1]
            working_directories.append(str(wd))
            return CompletedProcess(cmd, 0,
                'Model checking completed. No error has been found.\nFinished in 00s', '')
        with TemporaryDirectory() as td, patch('experiment.run_experiment.subprocess.run', side_effect=fake_java), patch('builtins.print'):
            rows=run_tlc(Path(td)/'test.jar',Path(td)/'RESULTS',timeout_s=15)
            self.assertEqual([r['result'] for r in rows],['PASS']*3)
            self.assertEqual(len(set(working_directories)),3)
            self.assertTrue((Path(td)/'RESULTS/tlc/large.log').is_file())
