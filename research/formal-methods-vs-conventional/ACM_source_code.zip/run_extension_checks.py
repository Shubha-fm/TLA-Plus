"""One command to execute the independent tests and generate their audit outputs."""
import hashlib,json,pathlib,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parent
COMMANDS=[
 [sys.executable,'-m','unittest','discover','-s','tests','-v'],
 [sys.executable,'-m','unittest','independent.test_spec_oracle','-v'],
 [sys.executable,'-m','unittest','discover','-s','additional_case_studies/tests','-v'],
 [sys.executable,'-m','independent.approval_oracle'],
 [sys.executable,'-m','additional_case_studies.run_cases'],
 [sys.executable,'-m','bibliography_audit.audit_bib'],
 [sys.executable,'-m','analysis.make_extended_figures'],
]
started=time.perf_counter();outputs=[]
for cmd in COMMANDS:
    cp=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True,timeout=90)
    outputs.append({'command':' '.join(cmd),'returncode':cp.returncode,'stdout':cp.stdout[-4000:], 'stderr':cp.stderr[-1500:]})
    print('PASS' if cp.returncode==0 else 'FAIL',cmd[-2:])
    if cp.returncode!=0:break
paths=['spec/ApprovalService.tla','independent/approval_oracle.py',
       'additional_case_studies/spec/RailwayCrossing.tla',
       'additional_case_studies/spec/JobQueue.tla','additional_case_studies/implementations.py',
       'additional_case_studies/oracles.py','references.bib']
manifest={p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}
report={'test_commands':outputs, 'all_pass':all(x['returncode']==0 for x in outputs) and len(outputs)==len(COMMANDS),
    'duration_seconds':round(time.perf_counter()-started,5),
    'evidence_files_sha256':manifest,'limitations':['new TLC model checks NOT_RUN without official jar',
    'publisher bibliographic lookup incomplete offline', 'models are synthetic, not industrial artifacts']}
folder=ROOT/'INDEPENDENT_EXTENSION_RESULTS';folder.mkdir(exist_ok=True)
(folder/'QA_RESULTS.json').write_text(json.dumps(report,indent=2))
if not report['all_pass']:raise SystemExit(1)
