import unittest
from experiment.system import CASES
from independent.approval_oracle import compare, transition, initial
class IndependentOracleTests(unittest.TestCase):
    def test_one_step_reference(self):
        s=initial(1)
        n,accepted=transition(s,'release',0,2,1)
        self.assertFalse(accepted);self.assertEqual(n,s)
    def test_all_three_configurations(self):
        for c in CASES:
            result=compare(c)
            self.assertEqual(result['mismatch_count'],0)
            self.assertEqual(result['distinguished_mutants'],result['applicable_mutants'])
if __name__=='__main__':unittest.main()
