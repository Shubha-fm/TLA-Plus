"""Independent, hand-transcribed projection of ApprovalService.tla.

This module intentionally NEVER calls experiment.system.initial/apply to compute
its expected transitions. The TLA+ lastOp/lastTarget diagnostic fields are hidden
in the projection; disabled TLA+ actions correspond to Python (state, False).
This is an executable cross-check, NOT an independently reviewed refinement proof.
"""
from collections import deque
from dataclasses import dataclass
import hashlib, json, pathlib, time
from experiment.system import CASES, MUTANTS, State, apply, mutant_applicable, initial as implementation_initial

SPEC = pathlib.Path(__file__).resolve().parents[1]/'spec'/'ApprovalService.tla'
OPS = ('assess','update','retry','release')
@dataclass(frozen=True)
class AbstractState:
    versions: tuple
    approvals: tuple
    releases: tuple
    retries: tuple

def initial(n):
    return AbstractState(tuple([1]*n),tuple([0]*n),tuple([False]*n),tuple([0]*n))

def replace_at(items, i, value):
    out=list(items);out[i]=value;return tuple(out)

def transition(s, op, i, max_version, max_retries):
    """Direct implementation of guards and postconditions from the TLA+ actions."""
    v=s.versions; a=s.approvals; r=s.releases; t=s.retries
    if op=='assess' and not r[i]:
        return AbstractState(v,replace_at(a,i,v[i]),r,t), True
    if op=='update' and not r[i] and v[i] < max_version:
        return AbstractState(replace_at(v,i,v[i]+1),replace_at(a,i,0),r,t), True
    if op=='retry' and not r[i] and t[i] < max_retries:
        return AbstractState(v,replace_at(a,i,0),r,replace_at(t,i,t[i]+1)), True
    if op=='release' and not r[i] and a[i]==v[i]:
        return AbstractState(v,a,replace_at(r,i,True),t), True
    return s, False

def project(s):
    return State(s.versions,s.approvals,s.releases,s.retries)

def compare(case, depth=None):
    if depth is None: depth=case.depth
    q=deque([(initial(case.objects),())]); seen={q[0][0]}; transitions=0; errors=[]; mutant_witnesses={}
    start=time.perf_counter()
    initial_match=(implementation_initial(case)==project(initial(case.objects)))
    if not initial_match: errors.append({"error":"Initial projected states do not match"})
    while q:
        s, prefix=q.popleft()
        if len(prefix)>=depth: continue
        for op in OPS:
            for i in range(case.objects):
                expected, accepted=transition(s,op,i,case.max_version,case.max_retries)
                actual, actual_accepted=apply(project(s),(op,i),case)
                transitions += 1
                if (project(expected),accepted) != (actual,actual_accepted):
                    errors.append({'prefix':prefix,'action':[op,i], 'expected':repr(expected),'actual':repr(actual),'expected_accept':accepted,'actual_accept':actual_accepted})
                for mutant in MUTANTS:
                    if mutant in mutant_witnesses or not mutant_applicable(case,mutant): continue
                    actual_mutant, mutant_accepted=apply(project(s),(op,i),case,mutant)
                    if (actual_mutant,mutant_accepted)!=(project(expected),accepted):
                        mutant_witnesses[mutant]={'prefix':[list(x) for x in prefix],'trigger':[op,i]}
                if accepted and expected not in seen:
                    seen.add(expected);q.append((expected,prefix+((op,i),)))
    return {'case':case.name,'oracle':'specification-transcribed; independent of experiment.system.apply',
        'projection':'version, approval, released, retries (excludes lastOp/lastTarget)',
        'depth_limit':depth,'reference_states':len(seen),'checked_action_outcomes':transitions,
        'initial_state_match':initial_match,'mismatch_count':len(errors),'mismatch_examples':errors[:20],
        'applicable_mutants':sum(mutant_applicable(case,m) for m in MUTANTS),
        'distinguished_mutants':len(mutant_witnesses),'mutant_witnesses':mutant_witnesses,
        'runtime_seconds':round(time.perf_counter()-start,6)}

def audit_spec_text():
    """Check that the intended action/operator names occur in the exact supplied model.
    This is not a parser and cannot substitute for a TLA+ semantic check."""
    source=SPEC.read_text()
    names=['Assess(o)','Update(o)','Retry(o)','Release(o)','TypeOK', 'NoUnsafeRelease','RetryInvalidates','UpdateInvalidates']
    return {'spec_file':'spec/ApprovalService.tla','sha256':hashlib.sha256(SPEC.read_bytes()).hexdigest(),
            'required_operators_present':{n:n in source for n in names}}

if __name__=='__main__':
    root=pathlib.Path(__file__).resolve().parents[1]
    out=root/'independent'/'results';out.mkdir(exist_ok=True)
    summary={'source_audit':audit_spec_text(),'cases':[compare(c) for c in CASES]}
    (out/'approval_conformance.json').write_text(json.dumps(summary,indent=2))
    for c in summary['cases']:
        print(c['case'], 'states=',c['reference_states'],'actions=',c['checked_action_outcomes'], 'mismatches=',c['mismatch_count'], 'mutants=',c['distinguished_mutants'],'/',c['applicable_mutants'])
    if any(c['mismatch_count'] for c in summary['cases']):raise SystemExit('Reference implementation disagrees with spec-derived oracle')
