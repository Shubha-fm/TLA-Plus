"""Fixed black-box conventional tests and held-out randomized validation."""
from __future__ import annotations
import random
from experiment.system import ACTIONS, initial, apply, Case


def conventional_traces(case: Case):
    """Frozen minimal requirements-derived test scripts (not mutant-aware)."""
    one = 0
    scripts = [
        [('release',one)],
        [('assess',one),('release',one)],
        [('assess',one),('update',one),('release',one)],
        [('assess',one),('retry',one),('release',one)],
        [('assess',one),('release',one),('release',one)],
        [('assess',one),('release',one),('update',one)],
        [('assess',one),('release',one),('assess',one)],
        [('update',one),('update',one),('update',one)],
        [('retry',one),('retry',one),('retry',one)],
    ]
    if case.objects > 1:
        scripts += [
            [('assess',1),('update',0)],
            [('assess',1),('retry',0)],
            [('assess',0),('release',0)],
            [('assess',1),('assess',0)],
        ]
    return scripts


def heldout_traces(case: Case, seed: int, count: int, length: int):
    """Generated only for validation, never supplied to development test suite."""
    rng = random.Random(seed)
    for _ in range(count):
        yield [(rng.choice(ACTIONS), rng.randrange(case.objects)) for _ in range(length)]


def compare_trace(case: Case, mutant: str, trace):
    ref = initial(case)
    candidate = initial(case)
    for index, action in enumerate(trace):
        ref, ref_accept = apply(ref, action, case)
        candidate, candidate_accept = apply(candidate, action, case, mutant)
        if ref != candidate or ref_accept != candidate_accept:
            return {'step': index + 1, 'action': list(action),
                    'reference_accept': ref_accept, 'candidate_accept': candidate_accept}
    return None
