"""Generate reproducible raw CSV, JSON and per-mutant counterexample logs.
Run: python -m experiment.run_experiment --out RESULTS --seeds 41 42 43
Optional TLC: --tlc-jar path/to/tla2tools.jar
"""
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import os
import platform
import re
import shutil
import tempfile
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from time import perf_counter
from dataclasses import asdict
from experiment.system import MUTANTS, CASES, mutant_applicable
from experiment.testsuites import conventional_traces, heldout_traces, compare_trace
from experiment.explore import explore

ROOT = Path(__file__).resolve().parents[1]


def iso_now():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, sort_keys=True) + '\n', encoding='utf-8')


def run_tlc(jar: Path, out: Path, timeout_s=900):
    """Run official TLC per configuration in isolated directories.

    Each temporary directory contains ApprovalService.tla AND the selected
    ApprovalService.cfg. TLC reads the adjacent configuration automatically.
    Isolation also prevents the within-one-second state-directory collision.
    The model and each configuration are copied byte-for-byte, not modified.
    """
    configs = ('small', 'medium', 'large')
    rows = []
    logdir = out / 'tlc'
    logdir.mkdir(parents=True, exist_ok=True)
    model = ROOT / 'spec' / 'ApprovalService.tla'
    for name in configs:
        cfg = ROOT / 'configs' / f'{name}.cfg'
        with tempfile.TemporaryDirectory(prefix=f'acm_tlc_{name}_') as working:
            work = Path(working)
            shutil.copy2(model, work / 'ApprovalService.tla')
            shutil.copy2(cfg, work / 'ApprovalService.cfg')
            # Using -jar is supported by official TLC tools. The default
            # same-name configuration is auto-discovered beside the module.
            cmd = ['java', '-XX:+UseParallelGC', '-jar', str(jar),
                   '-workers', '1', 'ApprovalService.tla']
            started = perf_counter()
            try:
                proc = subprocess.run(cmd, cwd=str(work),
                                      capture_output=True, text=True,
                                      timeout=timeout_s, check=False)
                log = proc.stdout + '\n--- STDERR ---\n' + proc.stderr
                rc = proc.returncode
                if ('Model checking completed. No error has been found.' in log
                        and rc == 0 and 'Error:' not in log):
                    result = 'PASS'
                elif ('ConfigFileException' in log or 'File not found' in log
                      or 'directory already exists' in log):
                    result = 'SETUP_ERROR'
                elif re.search(r'Error: (Invariant|Temporal property|Deadlock)',log,re.I):
                    result = 'VIOLATION'
                elif ('OutOfMemoryError' in log or 'Java heap space' in log):
                    result = 'RESOURCE_ERROR'
                elif 'Error:' in log or rc != 0:
                    result = 'ERROR'
                else:
                    result = 'INCOMPLETE'
            except subprocess.TimeoutExpired as exc:
                raw = exc.stdout or ''
                log = raw.decode(errors='replace') if isinstance(raw,bytes) else raw
                log += f'\nTIMEOUT after {timeout_s} seconds\n'
                rc, result = -1, 'TIMEOUT'
            complete_log = ('Invocation: java -XX:+UseParallelGC -jar <user TLC jar> '
                            '-workers 1 ApprovalService.tla\n'
                            f'Configuration: {name}.cfg (copied as ApprovalService.cfg)\n'
                            f'Source module SHA256: {hashlib.sha256(model.read_bytes()).hexdigest()}\n'
                            f'Configuration SHA256: {hashlib.sha256(cfg.read_bytes()).hexdigest()}\n'
                            + log)
            (logdir/f'{name}.log').write_text(complete_log,encoding='utf-8')
            generated = re.findall(r'([\d,]+) states generated',log)
            distinct = re.findall(r'([\d,]+) distinct states found',log)
            row = {'case':name,'result':result,'returncode':rc,
                   'duration_seconds':round(perf_counter()-started,6),
                   'states_generated':int(generated[-1].replace(',','')) if generated else None,
                   'distinct_states':int(distinct[-1].replace(',','')) if distinct else None,
                   'log':f'tlc/{name}.log',
                   'model_sha256':hashlib.sha256(model.read_bytes()).hexdigest(),
                   'config_sha256':hashlib.sha256(cfg.read_bytes()).hexdigest()}
            rows.append(row)
            print('TLC',name,result,flush=True)
    return rows


def tlc_recheck(jar: Path, out: Path, timeout_s: int):
    """Recheck TLC without rerunning or changing the original Python CSV."""
    if not (out/'raw_results.csv').exists():
        raise FileNotFoundError('Cannot find raw_results.csv in '+str(out))
    original = out / 'tlc_summary.json'
    if original.exists() and not (out/'tlc_summary_before_recheck.json').exists():
        shutil.copy2(original, out/'tlc_summary_before_recheck.json')
    old_logs = out/'tlc'
    archive = out/'tlc_before_recheck'
    if old_logs.is_dir() and not archive.exists():
        shutil.copytree(old_logs,archive)
    rows = run_tlc(jar,out,timeout_s)
    write_json(out/'tlc_summary.json',rows)
    provenance = {'recheck_utc':iso_now(), 'tlc_jar_sha256':hashlib.sha256(jar.read_bytes()).hexdigest(),
                  'java_version':(lambda x:(x.stdout+x.stderr).strip())(subprocess.run(
                      ['java','-version'],capture_output=True,text=True,check=False)),
                  'invocation':'model and selected cfg copied to isolated temporary folder; java -jar',
                  'original_python_results_preserved':True,
                  'tlc_outcomes':[{k:r[k] for k in ('case','result','returncode','states_generated','distinct_states')} for r in rows]}
    write_json(out/'tlc_recheck_metadata.json',provenance)
    with (out/'summary.txt').open('a',encoding='utf-8') as f:
        f.write('\nTLC RECHECK '+provenance['recheck_utc']+': '+
                '; '.join(f"{r['case']}={r['result']}" for r in rows)+'\n')
    return 0 if all(r['result']=='PASS' for r in rows) else 2


def main(argv=None):
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, default=Path('RESULTS'))
    parser.add_argument('--seeds', nargs='+', type=int, default=[41,42,43,44,45])
    parser.add_argument('--validation-traces', type=int, default=400)
    parser.add_argument('--validation-length', type=int, default=20)
    parser.add_argument('--max-states', type=int, default=60000)
    parser.add_argument('--tlc-jar', type=Path, default=None)
    parser.add_argument('--tlc-timeout', type=int, default=900)
    parser.add_argument('--tlc-only', action='store_true',
                        help='Retry TLC on the existing RESULTS folder, preserving Python data and prior TLC logs')
    args = parser.parse_args(argv)
    if args.validation_traces <= 0 or args.validation_length <= 0:
        parser.error('validation-traces and validation-length must be positive')
    out = args.out.resolve()
    out.mkdir(parents=True, exist_ok=True)
    if args.tlc_only:
        if not args.tlc_jar:
            parser.error('--tlc-only requires --tlc-jar')
        jar = args.tlc_jar.expanduser().resolve()
        if not jar.is_file():
            parser.error('Cannot find --tlc-jar at '+str(jar))
        return tlc_recheck(jar, out, args.tlc_timeout)
    started_at = iso_now()
    meta = {'started_utc': started_at, 'python': sys.version,
            'platform': platform.platform(), 'cases': [asdict(x) for x in CASES],
            'mutants': list(MUTANTS), 'validation_seeds': args.seeds,
            'validation_traces_per_seed': args.validation_traces,
            'validation_trace_length': args.validation_length,
            'max_states': args.max_states, 'design': 'synthetic one-fault mutant detection; not an empirical human study',
            'conditions': {'conventional': 'predefined unit test traces',
                           'formal_augmented': 'same predefined tests plus depth-bounded reference transition conformance',
                           'validation': 'separate held-out random traces'},
            'tools': {'tlc': 'run when --tlc-jar provided; otherwise NOT RUN'}}
    rows = []
    for case in CASES:
        print('CASE', case.name, 'objects', case.objects, 'depth', case.depth, flush=True)
        baseline_traces = conventional_traces(case)
        explorer = explore(case, args.max_states)
        write_json(out / 'exploration' / (case.name+'.json'), explorer)
        for mutant, witness in explorer['witnesses'].items():
            write_json(out / 'witnesses' / case.name / (mutant+'.json'), witness)
        conventional_detection = {}
        conventional_seconds = {}
        for mutant in MUTANTS:
            tick = perf_counter()
            match = next((compare_trace(case, mutant, trace) for trace in baseline_traces
                          if compare_trace(case, mutant, trace) is not None), None)
            conventional_detection[mutant] = match
            conventional_seconds[mutant] = round(perf_counter() - tick, 8)
        for seed in args.seeds:
            holdout = list(heldout_traces(case, seed, args.validation_traces, args.validation_length))
            for mutant in MUTANTS:
                v_start = perf_counter()
                failures = sum(1 for trace in holdout if compare_trace(case, mutant, trace) is not None)
                v_time = perf_counter() - v_start
                detected_c = conventional_detection[mutant] is not None
                detected_f = detected_c or mutant in explorer['witnesses']
                rows.append({
                    'case': case.name, 'objects': case.objects,
                    'max_version': case.max_version, 'max_retries': case.max_retries,
                    'depth_limit': case.depth, 'seed': seed, 'mutant': mutant,
                    'mutant_applicable': int(mutant_applicable(case, mutant)),
                    'conventional_detected': int(detected_c),
                    'formal_augmented_detected': int(detected_f),
                    'transition_conformance_detected': int(mutant in explorer['witnesses']),
                    'validation_failures': failures,
                    'validation_total': len(holdout),
                    'validation_detection_rate': round(failures / len(holdout), 6),
                    'baseline_scripts': len(baseline_traces),
                    'baseline_run_seconds': conventional_seconds[mutant],
                    'validation_run_seconds': round(v_time, 8),
                    'exploration_seconds_shared': explorer['runtime_seconds'],
                    'exploration_states_shared': explorer['unique_states'],
                    'exploration_transitions_shared': explorer['transition_count'],
                    'truncated': int(explorer['truncated_by_state_limit']),
                    'conventional_first_failure_step': conventional_detection[mutant]['step'] if detected_c else '',
                    'formal_witness_steps': len(explorer['witnesses'][mutant]['prefix'])+1 if mutant in explorer['witnesses'] else '',
                })
        print('  explored', explorer['unique_states'], 'reference states;',
              len(explorer['witnesses']), '/', len(MUTANTS), 'mutants distinguished',
              '(truncated)' if explorer['truncated_by_state_limit'] else '', flush=True)
    cols = list(rows[0])
    with (out/'raw_results.csv').open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader(); w.writerows(rows)
    tlc_rows = []
    if args.tlc_jar:
        jar = args.tlc_jar.expanduser().resolve()
        if not jar.is_file():
            parser.error('Cannot find --tlc-jar at ' + str(jar))
        tlc_rows = run_tlc(jar, out, args.tlc_timeout)
        meta['tools']['tlc'] = str(jar)
        meta['tools']['tlc_jar_sha256'] = hashlib.sha256(jar.read_bytes()).hexdigest()
        java_version = subprocess.run(['java','-version'], capture_output=True, text=True, check=False)
        meta['tools']['java_version'] = (java_version.stdout + java_version.stderr).strip()
        write_json(out/'tlc_summary.json', tlc_rows)
    meta['completed_utc'] = iso_now()
    meta['files_sha256'] = {}
    for relative in ('experiment/system.py','experiment/testsuites.py','experiment/explore.py',
                     'experiment/run_experiment.py','spec/ApprovalService.tla'):
        meta['files_sha256'][relative] = hashlib.sha256((ROOT/relative).read_bytes()).hexdigest()
    write_json(out/'run_metadata.json', meta)
    with (out/'summary.txt').open('w', encoding='utf-8') as f:
        f.write('RESEARCH PILOT: MUTATION / CONFORMANCE EVALUATION\n')
        f.write('Not a controlled human study. Repeated seeds are validation replications, not independent projects.\n\n')
        for case in CASES:
            selected = [r for r in rows if r['case'] == case.name and r['seed'] == args.seeds[0]]
            eligible = [r for r in selected if r['mutant_applicable']]
            c = sum(r['conventional_detected'] for r in eligible)
            formal = sum(r['formal_augmented_detected'] for r in eligible)
            f.write(f'{case.name}: conventional {c}/{len(eligible)} applicable mutants; formal-augmented {formal}/{len(eligible)}; '
                    f"truncated={bool(selected[0]['truncated'])}\n")
        if args.tlc_jar:
            f.write('\nTLC: ' + '; '.join(f"{r['case']}={r['result']}" for r in tlc_rows) + '\n')
        else:
            f.write('\nTLC NOT RUN: re-run with --tlc-jar /path/to/tla2tools.jar\n')
    print((out/'summary.txt').read_text(encoding='utf-8'), flush=True)
    print('Saved:', out, flush=True)
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
