"""Release-gate case study: pure executable contract and independent mutants.
Standard-library only; every action returns (new_state, accepted).
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Tuple

ACTIONS = ('assess', 'update', 'retry', 'release')
MUTANTS = (
    'gate_bypass', 'stale_update', 'retry_stale', 'assess_previous',
    'cross_update', 'cross_retry', 'release_other', 'double_release',
    'update_after_release', 'retry_limit', 'assess_after_release',
    'update_jump', 'release_revokes_approval', 'assess_all',
    'retry_wrong_counter', 'update_keeps_old_approval_on_second_version',
)

def mutant_applicable(case: "Case", mutant: str) -> bool:
    """Predeclared structural applicability (independent of detections)."""
    cross = {'cross_update', 'cross_retry', 'release_other',
             'assess_all', 'retry_wrong_counter'}
    if case.objects < 2 and mutant in cross:
        return False
    if case.max_version < 3 and mutant == 'update_keeps_old_approval_on_second_version':
        return False
    return True

@dataclass(frozen=True)
class Case:
    name: str
    objects: int
    max_version: int
    max_retries: int
    depth: int

CASES = (
    Case('small', 1, 2, 1, 6),
    Case('medium', 2, 3, 1, 8),
    Case('large', 3, 3, 2, 8),
)

@dataclass(frozen=True)
class State:
    version: Tuple[int, ...]
    approval: Tuple[int, ...]
    released: Tuple[bool, ...]
    retries: Tuple[int, ...]


def initial(case: Case) -> State:
    n = case.objects
    return State((1,) * n, (0,) * n, (False,) * n, (0,) * n)


def set_at(seq: tuple, index: int, value: object) -> tuple:
    seq = list(seq)
    seq[index] = value
    return tuple(seq)


def set_many(state: State, **changes) -> State:
    d = asdict(state)
    d.update(changes)
    return State(**{key: tuple(value) for key, value in d.items()})


def apply(state: State, action: tuple[str, int], case: Case,
          mutant: str | None = None) -> tuple[State, bool]:
    """Ground-truth reference semantics if mutant is None.
    Mutants are one-at-a-time fault injections, not formal-method arm code.
    """
    operation, obj = action
    if operation not in ACTIONS or obj < 0 or obj >= case.objects:
        raise ValueError(f'Invalid action {action}')
    v, a, r, t = state.version, state.approval, state.released, state.retries
    other = (obj + 1) % case.objects
    if operation == 'assess':
        if r[obj] and mutant != 'assess_after_release':
            return state, False
        approved = v[obj] - 1 if mutant == 'assess_previous' else v[obj]
        new_approval = set_at(a, obj, approved)
        if mutant == 'assess_all' and case.objects > 1:
            new_approval = tuple(version for version in v)
        return set_many(state, approval=new_approval), True
    if operation == 'update':
        if r[obj] and mutant != 'update_after_release':
            return state, False
        if v[obj] >= case.max_version:
            return state, False
        next_version = v[obj] + (2 if mutant == 'update_jump' else 1)
        next_approval = (a if mutant == 'stale_update' or
                         (mutant == 'update_keeps_old_approval_on_second_version' and v[obj] >= 2)
                         else set_at(a, obj, 0))
        new_version = set_at(v, obj, next_version)
        if mutant == 'cross_update' and case.objects > 1:
            new_version = set_at(new_version, other, min(case.max_version, v[other] + 1))
        return set_many(state, version=new_version, approval=next_approval), True
    if operation == 'retry':
        if r[obj] or (t[obj] >= case.max_retries and mutant != 'retry_limit'):
            return state, False
        new_approval = a if mutant == 'retry_stale' else set_at(a, obj, 0)
        if mutant == 'cross_retry' and case.objects > 1:
            new_approval = set_at(new_approval, other, 0)
        retry_target = other if mutant == 'retry_wrong_counter' and case.objects > 1 else obj
        return set_many(state, approval=new_approval,
                        retries=set_at(t, retry_target, t[retry_target] + 1)), True
    if operation == 'release':
        if r[obj] and mutant != 'double_release':
            return state, False
        if a[obj] != v[obj] and mutant != 'gate_bypass':
            return state, False
        target = other if mutant == 'release_other' and case.objects > 1 else obj
        new_approval = set_at(a, obj, 0) if mutant == 'release_revokes_approval' else a
        return set_many(state, released=set_at(r, target, True), approval=new_approval), True
    raise AssertionError(operation)


def state_dict(state: State):
    return asdict(state)


def independent_safety(state: State, case: Case) -> dict[str, bool]:
    """State-only checks; transition conformance additionally catches mutation errors."""
    return {
        'type_bounds': all(1 <= v <= case.max_version for v in state.version)
                       and all(0 <= t <= case.max_retries for t in state.retries),
        'valid_approval': all(a in (0, v) for a, v in zip(state.approval, state.version)),
        'released_has_approval': all(not r or a == v for r, a, v in
                                     zip(state.released, state.approval, state.version)),
    }
