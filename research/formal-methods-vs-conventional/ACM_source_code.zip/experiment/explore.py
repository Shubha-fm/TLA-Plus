"""Explicit bounded one-step implementation conformance oracle.
Not TLC, not a proof of Python source, and not proof of requirements validity.
"""
from __future__ import annotations
from collections import deque
from time import perf_counter
from experiment.system import initial, apply, ACTIONS, MUTANTS, Case, state_dict, independent_safety


def explore(case: Case, max_states: int = 60000):
    start = perf_counter()
    init = initial(case)
    queue = deque([(init, ())])
    visited = {init}
    witnesses = {}
    states_checked, transitions_checked = 0, 0
    max_observed_depth = 0
    all_actions = [(act, i) for act in ACTIONS for i in range(case.objects)]
    truncated = False
    while queue:
        state, prefix = queue.popleft()
        states_checked += 1
        max_observed_depth = max(max_observed_depth, len(prefix))
        safety = independent_safety(state, case)
        if not all(safety.values()):
            raise AssertionError(f'Reference contract itself violates safety: {safety}')
        if len(prefix) >= case.depth:
            continue
        for action in all_actions:
            reference_next, reference_accept = apply(state, action, case)
            transitions_checked += 1
            for mutant in MUTANTS:
                if mutant in witnesses:
                    continue
                candidate_next, candidate_accept = apply(state, action, case, mutant)
                if (candidate_next, candidate_accept) != (reference_next, reference_accept):
                    witnesses[mutant] = {
                        'prefix': [list(a) for a in prefix], 'trigger': list(action),
                        'reference_accepted': reference_accept,
                        'mutant_accepted': candidate_accept,
                        'reference_state': state_dict(reference_next),
                        'mutant_state': state_dict(candidate_next),
                    }
            if reference_next != state and reference_next not in visited:
                if len(visited) >= max_states:
                    truncated = True
                    queue.clear()
                    break
                visited.add(reference_next)
                queue.append((reference_next, prefix + (action,)))
    return {
        'state_count': states_checked,
        'unique_states': len(visited),
        'transition_count': transitions_checked,
        'max_depth_observed': max_observed_depth,
        'depth_limit': case.depth,
        'max_states_limit': max_states,
        'truncated_by_state_limit': truncated,
        'scope': 'Reference-reachable states at depth < depth_limit; one-step conformance checks',
        'runtime_seconds': round(perf_counter()-start, 6),
        'witnesses': witnesses,
    }
