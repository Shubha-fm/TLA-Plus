"""Generate descriptive tables from locally executed experiment CSV.
Does not perform significance testing or imply samples are independent projects.
"""
from __future__ import annotations
import argparse
import csv
import json
import statistics
from pathlib import Path


def main(argv=None):
    p = argparse.ArgumentParser()
    p.add_argument('--results', type=Path, default=Path('RESULTS'))
    p.add_argument('--tex', type=Path, default=Path('results_table.tex'))
    a = p.parse_args(argv)
    with (a.results/'raw_results.csv').open(newline='',encoding='utf-8') as f:
        rows = list(csv.DictReader(f))
    if not rows:
        p.error('Empty results CSV')
    case_names = list(dict.fromkeys(r['case'] for r in rows))
    items = []
    for name in case_names:
        cr = [r for r in rows if r['case'] == name]
        unique = [r for r in {r['mutant']:r for r in cr}.values() if int(r['mutant_applicable'])]
        detected_c = sum(int(r['conventional_detected']) for r in unique)
        detected_f = sum(int(r['formal_augmented_detected']) for r in unique)
        seed_rates = []
        for seed in sorted({r['seed'] for r in cr}):
            sr = [r for r in cr if r['seed'] == seed and int(r['mutant_applicable'])]
            seed_rates.append(sum(int(r['validation_failures']) for r in sr) /
                              sum(int(r['validation_total']) for r in sr))
        items.append(dict(case=name, mut_count=len(unique), conventional=detected_c,
                          formal_augmented=detected_f,
                          mean_validation_rate=statistics.mean(seed_rates),
                          validation_seed_sd=statistics.stdev(seed_rates) if len(seed_rates)>1 else None,
                          exploration_states=int(unique[0]['exploration_states_shared']),
                          truncated=bool(int(unique[0]['truncated']))))
    (a.results/'descriptive_summary.json').write_text(json.dumps(items,indent=2)+'\n',encoding='utf-8')
    lines = [r'\begin{table}[t]', r'\caption{Local pilot results. Detection counts refer to the same synthetic mutants; they are not independent project outcomes.}',
             r'\label{tab:localresults}', r'\centering',r'\small',
             r'\begin{tabular}{@{}lrrrr@{}}',r'\toprule',
             r'Case & Mutants & Tests & Tests+model & States \\', r'\midrule']
    for item in items:
        lines.append("{} & {} & {} & {} & {} ".format(item["case"], item["mut_count"], item["conventional"], item["formal_augmented"], item["exploration_states"]) + chr(92)*2)
    lines += [r'\bottomrule',r'\end{tabular}',
              r'\end{table}',
              r'\noindent\textit{Caution:} Small bounded model-based pilot; no human-subject causal inference.']
    a.tex.parent.mkdir(parents=True, exist_ok=True)
    a.tex.write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print('Saved',a.results/'descriptive_summary.json')
    print('Saved',a.tex)
    for i in items:
        print(f"{i['case']}: {i['conventional']}/{i['mut_count']} tests, {i['formal_augmented']}/{i['mut_count']} augmented")

if __name__=='__main__':
    main()
