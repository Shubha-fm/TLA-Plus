"""Offline complete-field audit of every BibTeX entry. No publisher verification claim."""
import csv, json, pathlib, re
ROOT=pathlib.Path(__file__).resolve().parents[1]
BIB=ROOT/'references.bib'
RESULTS=ROOT/'bibliography_audit'/'results'
RE_DOI=re.compile(r'^10\.\d{4,9}/\S+$',re.I)

def entries(text):
    parts=re.split(r'(?=^@\w+\{)',text,flags=re.M)
    for p in parts:
        hit=re.match(r'@(\w+)\{([^,]+),',p)
        if not hit:continue
        typ,key=hit.groups()
        fields={}
        # Parse balanced field braces (including BibTeX accents inside names).
        for m in re.finditer(r'^\s*([A-Za-z]+)\s*=\s*\{',p,flags=re.M):
            start=m.end();level=1;pos=start
            while pos<len(p) and level:
                if p[pos]=='{':level+=1
                elif p[pos]=='}':level-=1
                pos+=1
            if level==0:fields[m.group(1).lower()]=p[start:pos-1]
        yield typ.lower(),key,fields

def audit():
    source=BIB.read_text(encoding='utf-8'); items=list(entries(source))
    documents='\n'.join(p.read_text(encoding='utf-8') for p in ROOT.rglob('*.tex') if 'results' not in p.parts)
    cited=set()
    for citation in re.findall(r'\\cite(?:\[[^\]]*\])*\{([^}]+)\}',documents):
        cited.update(x.strip() for x in citation.split(','))
    checked_file=ROOT/'bibliography_audit'/'manual_checked.json'
    checked={r['key']:r for r in json.loads(checked_file.read_text(encoding='utf-8'))} if checked_file.exists() else {}
    keys={key for _,key,_ in items};seen={};rows=[]
    for typ,key,f in items:
        issues=[]
        required=['author','title','year']
        if typ=='article':required+=['journal']
        if typ=='inproceedings':required+=['booktitle']
        if typ=='book':required+=['publisher']
        for k in required:
            if not f.get(k):issues.append('missing_'+k)
        if key in seen:issues.append('duplicate_key')
        seen[key]=1
        if f.get('doi') and not RE_DOI.match(f['doi']):issues.append('invalid_doi_syntax')
        if not f.get('doi'):issues.append('doi_absent_not_necessarily_error')
        if f.get('year') and not re.fullmatch(r'\d{4}',f['year']):issues.append('invalid_year')
        if f.get('author','').endswith('and others'):issues.append('abbreviated_author_list')
        rows.append({'key':key,'type':typ,'title':f.get('title',''), 'year':f.get('year',''),
                     'doi':f.get('doi',''),'cited':key in cited,
                     'structural_errors':';'.join(i for i in issues if i!='doi_absent_not_necessarily_error'),
                     'doi_missing':not bool(f.get('doi')),
                     'publisher_metadata_status':checked.get(key,{}).get('review','NOT_INDEPENDENTLY_VERIFIED'),
                     'publisher_url':checked.get(key,{}).get('url',('https://doi.org/'+f['doi'] if f.get('doi') else ''))})
    stats={'entries':len(items),'cited':sum(r['cited'] for r in rows),
           'with_doi':sum(bool(r['doi']) for r in rows),
           'without_doi':sum(r['doi_missing'] for r in rows),
           'missing_citations':sorted(cited-keys),
           'structural_flags':[{r['key']:r['structural_errors']} for r in rows if r['structural_errors']],
           'externally_corroborated':sum(r['publisher_metadata_status']!='NOT_INDEPENDENTLY_VERIFIED' for r in rows),
           'not_externally_corroborated':sum(r['publisher_metadata_status']=='NOT_INDEPENDENTLY_VERIFIED' for r in rows),
           'scope':'100% entry-level offline structural check; sample external metadata checks; not bulk publisher verification'}
    RESULTS.mkdir(parents=True,exist_ok=True)
    with (RESULTS/'all_70_structural_audit.csv').open('w',newline='',encoding='utf-8-sig') as fp:
        w=csv.DictWriter(fp,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    (RESULTS/'audit_summary.json').write_text(json.dumps(stats,indent=2), encoding='utf-8')
    print(json.dumps(stats,indent=2))
    return stats
if __name__=='__main__': audit()
