"""Optional LIVE Crossref verification of every DOI, plus suggestions for non-DOI entries.
Run on a networked machine: python -m bibliography_audit.verify_publishers --online
Never overwrites BibTeX, never treats no DOI as an error; writes audit only.
"""
import argparse, csv, difflib, json, pathlib, time, urllib.parse, urllib.request, urllib.error
ROOT=pathlib.Path(__file__).resolve().parents[1]
DATA=ROOT/'bibliography_audit'/'results'/'all_70_structural_audit.csv'

def fetch(url,timeout=14):
    req=urllib.request.Request(url,headers={'User-Agent':'ACM-FM-Study-MetadataAudit/1.0 (metadata verification)','Accept':'application/json'})
    with urllib.request.urlopen(req,timeout=timeout) as response:return json.load(response)['message']

def clean(title):
    return ''.join(c.lower() for c in title if c.isalnum() or c.isspace()).strip()

def validate(online=False,delay=0.3):
    with DATA.open(newline='', encoding='utf-8-sig') as fp:rows=list(csv.DictReader(fp))
    reviewed=[]
    for record in rows:
        result={'key':record['key'],'bib_title':record['title'],'bib_doi':record['doi'],
                'status':'NOT_CHECKED' if not online else 'LOOKUP_NOT_RUN',
                'publisher_title':'','publisher_doi':'','publisher_year':'','title_similarity':'','error':''}
        if online:
            doi=record['doi']
            if doi:
                endpoint='https://api.crossref.org/works/'+urllib.parse.quote(doi,safe='/')
                status_success='DOI_METADATA_FOUND'
            else:
                query=urllib.parse.urlencode({'query.bibliographic':record['title'],'rows':1,'select':'DOI,title,published,author'})
                endpoint='https://api.crossref.org/works?'+query
                status_success='SUGGESTION_ONLY_NOT_VERIFIED'
            try:
                payload=fetch(endpoint)
                if not doi:payload=(payload.get('items') or [None])[0]
                if payload is None:raise ValueError('no Crossref candidates')
                title=(payload.get('title') or [''])[0]
                sim=difflib.SequenceMatcher(None,clean(record['title']),clean(title)).ratio()
                published=(payload.get('published') or payload.get('issued') or {}).get('date-parts',[[None]])[0][0]
                result.update(publisher_title=title,publisher_doi=payload.get('DOI',''),
                    publisher_year=published,title_similarity=round(sim,4),status=status_success)
                if doi and sim<0.88:result['status']='DOI_TITLE_MISMATCH_REVIEW'
                if not doi and sim<0.90:result['status']='LOW_CONFIDENCE_SUGGESTION'
            except Exception as e:
                result.update(status='LOOKUP_FAILED',error=f'{type(e).__name__}: {str(e)[:180]}')
            time.sleep(delay)
        reviewed.append(result)
    out=DATA.with_name('publisher_online_crossref_audit.csv')
    with out.open('w',newline='',encoding='utf-8-sig') as fp:
        w=csv.DictWriter(fp,fieldnames=list(reviewed[0]));w.writeheader();w.writerows(reviewed)
    print('Wrote',out,'records=',len(reviewed),'online=',online)
    return reviewed
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--online',action='store_true');p.add_argument('--delay',type=float,default=.3)
    args=p.parse_args();validate(args.online,args.delay)
